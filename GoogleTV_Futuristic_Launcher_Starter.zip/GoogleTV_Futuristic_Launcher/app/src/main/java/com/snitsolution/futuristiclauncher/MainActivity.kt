package com.snitsolution.futuristiclauncher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 13, 29)
    private val accent = Color.rgb(45, 160, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildDashboard()
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 28, 42, 24)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(bg, Color.rgb(10, 28, 58), Color.rgb(5, 10, 22))
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "SN  /  SMART TV"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val clock = TextView(this).apply {
            text = "  •  YOUR ENTERTAINMENT HUB"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        header.addView(brand)
        header.addView(clock)
        root.addView(header)

        val hero = TextView(this).apply {
            text = "WELCOME HOME\n\nYour entertainment, all in one place."
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(28, 12, 28, 12)
            background = rounded(Color.rgb(20, 48, 88), 24)
        }
        val heroParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 180
        ).apply { topMargin = 28; bottomMargin = 24 }
        root.addView(hero, heroParams)

        val section = TextView(this).apply {
            text = "YOUR APPS"
            textSize = 16f
            setTextColor(Color.rgb(170, 205, 245))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(section)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val apps = listOf(
            "YouTube" to "com.google.android.youtube.tv",
            "Netflix" to "com.netflix.ninja",
            "Prime Video" to "com.amazon.amazonvideo.livingroom",
            "Settings" to "com.android.tv.settings"
        )
        apps.forEach { (label, pkg) ->
            val tile = TextView(this).apply {
                text = label
                textSize = 17f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = rounded(Color.rgb(24, 39, 65), 18)
                setOnFocusChangeListener { v, focused ->
                    v.background = rounded(
                        if (focused) Color.rgb(25, 105, 190) else Color.rgb(24, 39, 65),
                        18
                    )
                    v.scaleX = if (focused) 1.06f else 1f
                    v.scaleY = if (focused) 1.06f else 1f
                }
                setOnClickListener { launchPackage(pkg, label) }
            }
            val lp = LinearLayout.LayoutParams(0, 112, 1f).apply {
                topMargin = 18
                marginEnd = 14
            }
            row.addView(tile, lp)
        }
        root.addView(row)

        val footer = TextView(this).apply {
            text = "Use your TV remote • Select an app to open"
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(footer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        row.getChildAt(0)?.requestFocus()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(2, accent)
        }

    private fun launchPackage(pkg: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "$label is not installed or has no TV launch activity", Toast.LENGTH_SHORT).show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return super.onKeyDown(keyCode, event)
        }
        return super.onKeyDown(keyCode, event)
    }
}
